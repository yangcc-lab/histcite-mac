Graphviz 2.2.1, CPL 1.0; sanos sorting adapter, BSD-3-Clause.
Full licenses and source attribution are in ui/THIRD-PARTY.txt.

Rebuild:
  mkdir -p vendor
  tar -xzf graphviz-2.2.1.tar.gz -C vendor
  EMCC=/path/to/emsdk/upstream/emscripten/emcc python3 scripts/build_graphviz.py

Use Emscripten 4.0.10. Output: ui/graphviz.js (self-contained WASM/JS).
The build substitutes hc_legacy_qsort for C library qsort. The upstream
Graphviz source is unchanged; the complete portable config, sort source
and build command are included here. No HistCite executable or code is included.
